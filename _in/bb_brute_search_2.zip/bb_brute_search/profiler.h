/* ============================================================================
   profiler.h
============================================================================ */

#ifndef _profiler_DECLARED_
#define _profiler_DECLARED_

#include <time.h>

void profilergo(void);
double profilerstop(void);

static clock_t profilertimezero;

void profilergo(void) {
  profilertimezero=clock();
}

double profilerstop(void) {
  clock_t curtime;

  curtime=clock();
  return(double(curtime-profilertimezero)/CLK_TCK);
}

#endif
