#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <stdint.h>
using namespace std;

#include "rndlayers.h"
#include "profiler.h"

const int N=66;

int main(int argc, char *argv[]) {

	ifstream input("putin2d.scr", ios::binary);
	if (input) {
		input.seekg(0, input.end);
		int file_length = static_cast<int>(input.tellg());
		if (file_length == 6912) {

			uint8_t buffer[6912];
			input.seekg(0, input.beg);
			// this only works correctly for platforms where char == uint8_t
			// (i do not know any examples of such platforms, but this is beside the point)
			input.read(reinterpret_cast<char *>(buffer), file_length);
			if (!input) {
				cout << "  file reading was not successful, cannot continue\n" << endl;
				return 0;
			}
			input.close();
			rnd_layer goal=rnd_layer(buffer);

			// importing masks
			input.open("putin1mask0.scr");
			input.read(reinterpret_cast<char *>(buffer), 6912);
			goal.set_mask0(buffer);
			input.close();
			input.open("putin1mask1.scr");
			input.read(reinterpret_cast<char *>(buffer), 6912);
			goal.set_mask1(buffer);
			input.close();
			input.open("putin1mask2.scr");
			input.read(reinterpret_cast<char *>(buffer), 6912);
			goal.set_mask2(buffer);
			input.close();

			ofstream out("putin2d.2x2.#DB.2n.mini.log");

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for (int s0=0; s0<256; s0++) { // all possible seeds for the high byte
	for (int p=2; p<=2; p*=2) { // all possible variations of point numbers

		// the sequence of seeds that will be saved later
		uint16_t best_seeds[N+1];

		// conversion procedure itself
		rnd_layer stack[N];
		uint8_t prev_seed8=s0;
		int best_appr;

		for (int n=N; n>0; n--) {
			cout << ".";

			//profilergo();

			int last_seed8,best_seed16;
			best_appr=(256*192+1)*100;
			rnd_layer best_layer;
			for (int seed16=0; seed16<65536; seed16++) {
				//if (seed16%256==0) cout << setw(5) << setfill('0') << seed16
				//	<< char(8) << char(8) << char(8) << char(8) << char(8);

				SeedFastGalois24(seed16,prev_seed8);
				rnd_layer trial;
				trial.rndpoints(n*p);
				if (n<N) trial.xor(stack[N-n-1]);
				if (diff(trial,goal)<best_appr) {
					best_appr=diff(trial,goal);
					best_seed16=seed16;
					last_seed8=FG24a;
					best_layer=trial;
				}
			}
			//cout << "Iteration " << N-n << ":\t"
			//	<< setw(5) << best_appr << ", seed ["
			//	<< n << "," << best_seed << "]" << endl;
			stack[N-n]=best_layer; prev_seed8=last_seed8;
			best_seeds[N-n]=best_seed16;

			//cout << profilerstop() << endl;
		}

		// saving the results
		cout << endl << "n*" << p << " (" << s0 << ") => " << best_appr << endl;

		out << ";=============================================================" << endl;
		out << "; n*" << p << " (" << s0 << ") => " << best_appr << endl;
		for (int r=0; r<N/8+1; r++) {
			if (r*8==N) break;
			out << "\t\t\tdw\t" << best_seeds[r*8];
			if (r<N/8)
				for (int i=1; i<8; i++) {
					out << "," << best_seeds[r*8+i];
				}
			else
				for (int i=1; i<N-r*8; i++) {
					out << "," << best_seeds[r*8+i];
				}
			out << endl;
		}
		out << endl;


	}
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

			out.close();

		} else {
			cout << "  your file is not of the size 6144 bytes, cannot continue\n" << endl;
			return 0;
		}
		input.close();

		//cout << int(FastGalois24()) << " " << int(FastGalois24()) << " "
		//	<< int(FastGalois24()) << " " << int(FastGalois24()) << " "
		//	<< int(FastGalois24()) << " " << int(FastGalois24()) << endl;
	} else {
		cout << "  your file cannot be opened\n" << endl;
	}
	return 0;
}
