#ifndef __rndlayers__
#define __rndlayers__

#include <stdint.h>

uint8_t FG24a = 0xFF;
uint16_t FG24b = 0xFFFF;

void SeedFastGalois24(uint16_t seed, int idx=-1) {
	if (idx>=0) FG24a=idx;
	FG24b=seed;
}

uint8_t FastGalois24() {
	uint32_t t = ((FG24a<<16) + FG24b)<<1;
	FG24a = (t & 0xFF0000)>>16; //cout << "[" << int(FG24a) << ",";
	uint32_t s = (t & 0x1000000)>>24;
	FG24b = ((-s & 0xDB) ^ t) & 0xFFFF; //cout << int(FG24b) << ",";
	//cout << int(FG24b & 0xAA) << "," << int((FG24b & 0xFF00)>>8) << ",";
	//cout << int(FG24b & 0xAA)+int((FG24b & 0xFF00)>>8) << ","
	//	<< int(((FG24b & 0xAA)+((FG24b & 0xFF00)>>8)) & 0xFF) << "]" << endl;
	return ((FG24b & 0xAA)+((FG24b & 0xFF00)>>8)) & 0xFF;
}

inline int countbits(uint32_t v){
    /*int count = 0;
    for(int i = 0; i < 32; i++) {
		count += word & 0x01;
        word >>= 1;
	}*/
	v = v - ((v >> 1) & 0x55555555);                    // reuse input as temporary
	v = (v & 0x33333333) + ((v >> 2) & 0x33333333);     // temp
	return ((v + (v >> 4) & 0xF0F0F0F) * 0x1010101) >> 24; // count
    //return count;
}

int line2addr(int line) {
	// Y (zzxxxnnn) -> A (zznnn|xxx00000)
	int zz = (line & 0x00C0);
	int xxx = (line & 0x0038);
	int nnn = (line & 0x0007);
	return (zz+(nnn<<3)+(xxx>>3))<<5;
}

static uint8_t mask0[6144], mask1[6144], mask2[6144];

class rnd_layer {
private:
	uint8_t scr[6144];
public:
	rnd_layer();
	rnd_layer(uint8_t* src);
	void set_mask0(uint8_t* src);
	void set_mask1(uint8_t* src);
	void set_mask2(uint8_t* src);
	void xor(rnd_layer another);
	friend int diff(rnd_layer one, rnd_layer two);
	inline void plot(int x, int y);
	void rndpoints(int N);
};

rnd_layer::rnd_layer() {
	for (int i=0; i<6144; i++)
		scr[i]=0;
}

rnd_layer::rnd_layer(uint8_t* src) {
	for (int i=0; i<6144; i++)
		scr[i]=src[i];
}

void rnd_layer::set_mask0(uint8_t* src) {
	for (int i=0; i<6144; i++)
		mask0[i]=src[i];
}

void rnd_layer::set_mask1(uint8_t* src) {
	for (int i=0; i<6144; i++)
		mask1[i]=src[i];
}

void rnd_layer::set_mask2(uint8_t* src) {
	for (int i=0; i<6144; i++)
		mask2[i]=src[i];
}

void rnd_layer::xor(rnd_layer another) {
	//for (int i=0; i<6144; i++)
	//	scr[i] = scr[i] ^ another.scr[i];
	for (int i=0; i<6144/4; i++)
		((uint32_t *)scr)[i] = ((uint32_t *)scr)[i] ^ ((uint32_t *)another.scr)[i];
}

int diff(rnd_layer one, rnd_layer two) {
	int error0=0, error1=0, error2=0;
	for (int i=0; i<6144/4; i++) {
		uint32_t t=(((uint32_t *)one.scr)[i] ^ ((uint32_t *)two.scr)[i]) & ((uint32_t *)mask0)[i];
		error0 += countbits(t);
		error1 += countbits(t & ((uint32_t *)mask1)[i]);
		error2 += countbits(t & ((uint32_t *)mask2)[i]);
	}
	/*for (int r=0; r<24; r++) {
		for (int c=0; c<32; c++) {
			int cerr=0;
			for (int b=0; b<8; b++)
				cerr +=countbits(one.scr[r*32*8+c+32*b] ^ two.scr[r*32*8+c+32*b]);
			error+=cerr/64.0;
		}
	}*/
	//return (error0-error1)/4+(error1-error2)/2+error2;
	return error0+error1+error2+error2;
}

inline void rnd_layer::plot(int x, int y) {
	//static uint8_t pnts[8] = {0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01};
	//scr[(y<<5)+(x>>3)] ^= pnts[x & 0x07];

	//static uint8_t pnts[8] = {0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01};
	//scr[line2addr(y)+(x>>3)] ^= pnts[x & 0x03]; // version with the stripes bug :)

	static uint8_t pnts[4] = {0xC0, 0x30, 0x0C, 0x03};
	scr[line2addr(y & 0xFE)+(x>>3)] ^= pnts[(x & 0x06)>>1]; // 0x04 for stripes; 0x06 for true
	scr[line2addr((y & 0xFE)+1)+(x>>3)] ^= pnts[(x & 0x06)>>1];
	//scr[line2addr((y << 1)&0xFF)+(x>>3)] ^= pnts[(x & 0x06)>>1]; // 0x04 for stripes; 0x06 for true
	//scr[line2addr(((y << 1)&0xFF)+1)+(x>>3)] ^= pnts[(x & 0x06)>>1];
}

void rnd_layer::rndpoints(int N) {
	for (int i=0; i<N; i++) {
		int x=FastGalois24();
		int y=FastGalois24();
		if (y<192) plot(x,y);
	}
}

#endif